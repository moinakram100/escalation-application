sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("secondprojectfi.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);